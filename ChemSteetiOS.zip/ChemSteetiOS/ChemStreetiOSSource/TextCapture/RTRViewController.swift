//
//  RTRViewController.swift
//  TextCapture
//
//  Created by Prajwal on 07/10/17.
//  Copyright © 2017 HackInOut Inc. All rights reserved.
//

import UIKit
import AVFoundation

class RTRViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AVCaptureVideoDataOutputSampleBufferDelegate, RTRTextCaptureServiceDelegate {

	/// Cell ID for languagesTableView
	private let RTRVideoScreenCellName = "VideoScreenCell"
	private let RTRTextRegionsLayerName = "TextRegionsLayer"

	/// View with video preview layer
	@IBOutlet weak var previewView: UIView!
	/// Stop/Start capture button
	@IBOutlet weak var captureButton: UIButton!

	/// Recognition languages table
	@IBOutlet weak var languagesTableView: UITableView!
	@IBOutlet weak var recognizeLanguageButton: UIBarButtonItem!

	@IBOutlet weak var whiteBackgroundView: UIView!
	@IBOutlet weak var overlayView: RTRSelectedAreaView!

	private var session: AVCaptureSession?
	private var previewLayer: AVCaptureVideoPreviewLayer?
	private var engine: RTREngine?
	private var textCaptureService: RTRTextCaptureService?
	private var selectedRecognitionLanguages = Set(["English"])

    private let SessionPreset = AVCaptureSessionPreset1920x1080
	private var ImageBufferSize = CGSize(width: 1080, height: 1920)
	
	private var isRunning = true
	
	private let RecognitionLanguages = ["English",
										"French",
										"German",
										"Italian",
										"Polish",
										"PortugueseBrazilian",
										"Spanish"]

	private var selectedArea: CGRect = CGRect.zero {
		didSet {
			self.overlayView.selectedArea = selectedArea
		}
	}

//# MARK: - LifeCycle

	override func viewDidLoad() {
		super.viewDidLoad()

		let licensePath = (Bundle.main.bundlePath as NSString).appendingPathComponent("AbbyyRtrSdk.license")

		self.engine = RTREngine.sharedEngine(withLicense: NSData(contentsOfFile: licensePath) as Data!)
		assert(self.engine != nil)

		self.textCaptureService = self.engine?.createTextCaptureService(with: self)
		self.textCaptureService?.setRecognitionLanguages(selectedRecognitionLanguages)

		self.languagesTableView.register(UITableViewCell.self, forCellReuseIdentifier: RTRVideoScreenCellName)
		self.languagesTableView.tableFooterView = UIView(frame: CGRect.zero)
		self.languagesTableView.isHidden = true

		self.captureButton.isSelected = false
		self.captureButton.setTitle("Stop", for: UIControlState.selected)
		self.captureButton.setTitle("Start", for: UIControlState.normal)

		let recognizeLanguageButtonTitle = self.languagesButtonTitle()
		self.recognizeLanguageButton.title = recognizeLanguageButtonTitle

		let status = AVCaptureDevice.authorizationStatus(forMediaType: AVMediaTypeVideo)

		switch status {
			case AVAuthorizationStatus.authorized:
				self.configureCompletionAccess(true)
				break

			case AVAuthorizationStatus.notDetermined:
				AVCaptureDevice.requestAccess(forMediaType: AVMediaTypeVideo, completionHandler: { (granted) in
					DispatchQueue.main.async {
						self.configureCompletionAccess(granted)
					}
				})
				break

			case AVAuthorizationStatus.restricted, AVAuthorizationStatus.denied:
				self.configureCompletionAccess(false)
				break
		}
	}
	
	override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
		
		let wasRunning = self.isRunning
		self.textCaptureService?.stopTasks()
		self.clearScreenFromRegions()
		
		coordinator.animate(alongsideTransition: nil) { (context) in
			self.ImageBufferSize = CGSize(width:min(self.ImageBufferSize.width, self.ImageBufferSize.height),
			                              height:max(self.ImageBufferSize.width, self.ImageBufferSize.height))
			if(UIInterfaceOrientationIsLandscape(UIApplication.shared.statusBarOrientation)) {
				self.ImageBufferSize = CGSize(width:self.ImageBufferSize.height, height:self.ImageBufferSize.width);
			}
			
			self.updateAreaOfInterest()
			self.isRunning = wasRunning;

		}
		
	}

	override func viewWillDisappear(_ animated: Bool) {
		self.session?.stopRunning()
		self.isRunning = false
		self.captureButton.isSelected = false

		super.viewWillDisappear(animated)
	}

	override func viewDidLayoutSubviews() {
		super.viewDidLayoutSubviews()

		self.updatePreviewLayerFrame()
	}

	deinit {
		NotificationCenter.default.removeObserver(self)
	}

	override var prefersStatusBarHidden: Bool {
		return true
	}

//# MARK: - Private

	func configureCompletionAccess(_ accessGranted: Bool) {
		if !UIImagePickerController.isCameraDeviceAvailable(UIImagePickerControllerCameraDevice.rear) {
			self.captureButton.isEnabled = false
			print("Device has no camera")
			return
		}

		if !accessGranted {
			self.captureButton.isEnabled = false
			print("Camera access denied")
			return
		}

		self.configureAVCaptureSession()
		self.configurePreviewLayer()
		self.session?.startRunning()

		NotificationCenter.default.addObserver(self, selector:#selector(RTRViewController.avSessionFailed(_:)), name: NSNotification.Name.AVCaptureSessionRuntimeError, object: nil)
		NotificationCenter.default.addObserver(self, selector:#selector(RTRViewController.applicationDidEnterBackground(_:)), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
		NotificationCenter.default.addObserver(self, selector:#selector(RTRViewController.applicationWillEnterForeground(_:)), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)

		self.capturePressed("" as AnyObject)
	}

	private func configureAVCaptureSession() {
		self.session = AVCaptureSession()
		self.session?.sessionPreset = SessionPreset

		let device = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)

		do {
			let input = try AVCaptureDeviceInput(device: device)
			assert((self.session?.canAddInput(input))!, "impossible to add AVCaptureDeviceInput")
			self.session?.addInput(input)
		} catch let error as NSError {
			print(error.localizedDescription)
		}

		let videoDataOutput = AVCaptureVideoDataOutput()
		let videoDataOutputQueue = DispatchQueue(label: "videodataqueue", attributes: .concurrent)
		videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)

		videoDataOutput.videoSettings = NSDictionary(object: Int(kCVPixelFormatType_32BGRA),
		forKey: kCVPixelBufferPixelFormatTypeKey as! NSCopying) as [NSObject : AnyObject]

		assert((self.session?.canAddOutput(videoDataOutput))!, "impossible to add AVCaptureVideoDataOutput")
		self.session?.addOutput(videoDataOutput)

		let connection = videoDataOutput.connection(withMediaType: AVMediaTypeVideo)
		connection?.isEnabled = true
	}

	private func configurePreviewLayer() {
		self.previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
		self.previewLayer?.backgroundColor = UIColor.black.cgColor
		self.previewLayer?.videoGravity = AVLayerVideoGravityResize
		let rootLayer = self.previewView.layer
		rootLayer.insertSublayer(self.previewLayer!, at: 0)

		self.updatePreviewLayerFrame()
	}

	private func updatePreviewLayerFrame() {
		let orientation = UIApplication.shared.statusBarOrientation
		self.previewLayer?.connection.videoOrientation = self.videoOrientation(orientation)
		let viewBounds = self.view.bounds
		self.previewLayer?.frame = viewBounds
		self.selectedArea = viewBounds.insetBy(dx: viewBounds.width/8.0, dy: viewBounds.height/3.0)

		self.updateAreaOfInterest()
	}

	private func updateAreaOfInterest() {
		let affineTransform = CGAffineTransform(scaleX: self.ImageBufferSize.width * 1.0 / self.overlayView.frame.width, y: self.ImageBufferSize.height * 1.0 / self.overlayView.frame.height)
		let selectedRect = self.selectedArea.applying(affineTransform)
		self.textCaptureService?.setAreaOfInterest(selectedRect)
	}

	private func videoOrientation(_ orientation: UIInterfaceOrientation) -> AVCaptureVideoOrientation {
		switch orientation {
			case UIInterfaceOrientation.portrait:
				return AVCaptureVideoOrientation.portrait
			case UIInterfaceOrientation.portraitUpsideDown:
				return AVCaptureVideoOrientation.portraitUpsideDown
			case UIInterfaceOrientation.landscapeLeft:
				return AVCaptureVideoOrientation.landscapeLeft
			case UIInterfaceOrientation.landscapeRight:
				return AVCaptureVideoOrientation.landscapeRight
			default:
				return AVCaptureVideoOrientation.portrait
		}
	}

	private func languagesButtonTitle() -> String {
		if self.selectedRecognitionLanguages.count == 1 {
			return self.selectedRecognitionLanguages.first!
		}

		var languageCodes = [String]()

		for language in self.selectedRecognitionLanguages {
			let index = language.index(language.startIndex, offsetBy: 2)
			languageCodes.append(language.substring(to: index))
		}

		return languageCodes.joined(separator: " ")
	}

	private func tryToCloseLanguagesTable() {
		if self.selectedRecognitionLanguages.isEmpty {
			return
		}

		self.textCaptureService?.setRecognitionLanguages(self.selectedRecognitionLanguages)
		self.capturePressed("" as AnyObject)
		self.languagesTableView.isHidden = true
	}

//# MARK: - Drawing result

	private func processResult(_ areas: [RTRTextLine], _ mergeStatus:RTRResultStabilityStatus) {
		DispatchQueue.main.async {
			if !self.isRunning {
				return
			}

			if mergeStatus == RTRResultStabilityStatus.stable {
				self.isRunning = false
				self.captureButton.isSelected = false
				self.whiteBackgroundView.isHidden = false
			}

			self.drawTextLines(areas, mergeStatus)
		}
	}

	private func drawTextLines(_ textLines: [RTRTextLine], _ progress:RTRResultStabilityStatus) {
		self.clearScreenFromRegions()

		let textRegionsLayer = CALayer()
		textRegionsLayer.frame = self.previewLayer!.frame
		textRegionsLayer.name = RTRTextRegionsLayerName

        var stableText = [String]()
		for textLine in textLines {
			self.drawTextLine(textLine, textRegionsLayer, progress)
            if progress == .stable, let stableString = textLine.text {
                stableText.append(stableString)
            }
		}
        
        if stableText.count > 0 {
            let searchString = stableText.joined(separator: " ")
            self.fetchAPIWithText(searchString)
            
        }

		self.previewView.layer.addSublayer(textRegionsLayer)
	}

	func drawTextLine(_ textLine: RTRTextLine, _ layer: CALayer, _ progress: RTRResultStabilityStatus) {
		let topLeft = self.scaledPoint(cMocrPoint: textLine.quadrangle[0] as! NSValue)
		let bottomLeft = self.scaledPoint(cMocrPoint: textLine.quadrangle[1] as! NSValue)
		let bottomRight = self.scaledPoint(cMocrPoint: textLine.quadrangle[2] as! NSValue)
		let topRight = self.scaledPoint(cMocrPoint: textLine.quadrangle[3] as! NSValue)

		self.drawQuadrangle(topLeft, bottomLeft, bottomRight, topRight, layer, progress) 

		let recognizedString = textLine.text
        
		let textLayer = CATextLayer()
		let textWidth = self.distanceBetween(topLeft, topRight) 
		let textHeight = self.distanceBetween(topLeft, bottomLeft) 
		let rectForTextLayer = CGRect(x: bottomLeft.x, y: bottomLeft.y, width: textWidth, height: textHeight) 

		// Selecting the initial font size by rectangle
		let textFont = self.font(string: recognizedString!, rect: rectForTextLayer)
		textLayer.font = textFont
		textLayer.fontSize = textFont.pointSize
		textLayer.foregroundColor = self.progressColor(progress).cgColor
		textLayer.alignmentMode = kCAAlignmentCenter
		textLayer.string = recognizedString
		textLayer.frame = rectForTextLayer

		// Rotate the text layer
		let angle = asin((bottomRight.y - bottomLeft.y) / self.distanceBetween(bottomLeft, bottomRight))
		textLayer.anchorPoint = CGPoint(x: 0, y: 0)
		textLayer.position = bottomLeft
		textLayer.transform = CATransform3DRotate(CATransform3DIdentity, angle, 0, 0, 1)

		layer.addSublayer(textLayer)
	}

	func drawQuadrangle(_ p0: CGPoint, _ p1: CGPoint, _ p2: CGPoint, _ p3: CGPoint, _ layer: CALayer, _ progress: RTRResultStabilityStatus) {
		let area = CAShapeLayer()
		let recognizedAreaPath = UIBezierPath() 
		recognizedAreaPath.move(to: p0) 
		recognizedAreaPath.addLine(to: p1) 
		recognizedAreaPath.addLine(to: p2) 
		recognizedAreaPath.addLine(to: p3) 
		recognizedAreaPath.close() 
		area.path = recognizedAreaPath.cgPath 
		area.strokeColor = self.progressColor(progress).cgColor 
		area.fillColor = UIColor.clear.cgColor 
		layer.addSublayer(area) 
	}

	func progressColor(_ progress:RTRResultStabilityStatus) -> UIColor {
		switch progress {
			case RTRResultStabilityStatus.notReady, RTRResultStabilityStatus.tentative:
				return UIColor(hex: 0xFF6500)
			case RTRResultStabilityStatus.verified:
				return UIColor(hex: 0xC96500)
			case RTRResultStabilityStatus.available:
				return UIColor(hex: 0x886500)
			case RTRResultStabilityStatus.tentativelyStable:
				return UIColor(hex: 0x4B6500)
			case RTRResultStabilityStatus.stable:
				return UIColor(hex: 0x006500)
		}
	}

	/// Remove all visible regions
	private func clearScreenFromRegions() {
		// Get all visible regions
		let sublayers = self.previewView.layer.sublayers

		// Remove all layers with name - TextRegionsLayer
		for layer in sublayers! {
			if layer.name == RTRTextRegionsLayerName {
				layer.removeFromSuperlayer()
			}
		}
	}

	private func scaledPoint(cMocrPoint mocrPoint: NSValue) -> CGPoint {
		let layerWidth = self.previewLayer?.bounds.width
		let layerHeight = self.previewLayer?.bounds.height

		let widthScale = layerWidth! / ImageBufferSize.width
		let heightScale = layerHeight! / ImageBufferSize.height


		var point = mocrPoint.cgPointValue
		point.x *= widthScale
		point.y *= heightScale

		return point
	}

	private func distanceBetween(_ p1: CGPoint, _ p2: CGPoint) -> CGFloat {
		let vector = CGVector(dx: p2.x - p1.x, dy: p2.y - p1.y)
		return sqrt(vector.dx * vector.dx + vector.dy * vector.dy)
	}

	private func font(string: String, rect: CGRect) -> UIFont {
		var minFontSize: CGFloat = 0.1
		var maxFontSize: CGFloat = 72.0
		var fontSize: CGFloat = minFontSize

		let rectSize = rect.size

		while true {
			let attributes = [NSFontAttributeName: UIFont.boldSystemFont(ofSize: fontSize)]
			let labelSize = (string as NSString).size(attributes: attributes)

			if rectSize.height - labelSize.height > 0 {
				minFontSize = fontSize

				if rectSize.height * 0.99 - labelSize.height < 0 {
					break
				}
			} else {
				maxFontSize = fontSize
			}

			if abs(minFontSize - maxFontSize) < 0.01 {
				break
			}

			fontSize = (minFontSize + maxFontSize) / 2 
		}

		return UIFont.boldSystemFont(ofSize: fontSize)
	}

//# MARK: - RTRRecognitionServiceDelegate
	func onBufferProcessed(with textLines: [RTRTextLine]!, resultStatus: RTRResultStabilityStatus) {
		self.processResult(textLines, resultStatus)
	}

	func recognitionProgress(_ progress: Int32, warningCode: RTRCallbackWarningCode) {
		switch warningCode {
			case RTRCallbackWarningCode.textTooSmall:
				print("Text is too small")
				return
			default:
				break
		}
	}

	func onError(_ error: Error!) {
		print(error.localizedDescription)
	}

//# MARK: - AVCaptureVideoDataOutputSampleBufferDelegate

	func captureOutput(_ captureOutput: AVCaptureOutput!, didOutputSampleBuffer sampleBuffer: CMSampleBuffer!, from connection: AVCaptureConnection!) {
		if !self.isRunning {
			return
		}

		// Image is prepared
        DispatchQueue.main.async {
            let orientation = UIApplication.shared.statusBarOrientation
            connection.videoOrientation = self.videoOrientation(orientation)
            self.textCaptureService?.add(sampleBuffer)
        }
	}

//# MARK: - UITableViewDelegate

	func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		let language = RecognitionLanguages[indexPath.row]
		if !self.selectedRecognitionLanguages.contains(language) {
			self.selectedRecognitionLanguages.insert(language)
		} else {
			self.selectedRecognitionLanguages.remove(language)
		}

		self.recognizeLanguageButton.title = self.languagesButtonTitle()
		tableView .reloadRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
	}

//# MARK: - UITableViewDatasource

	func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
		return RecognitionLanguages.count
	}

	func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: nil)
		let language = RecognitionLanguages[indexPath.row]
		cell.textLabel?.text = language
		cell.accessoryType = self.selectedRecognitionLanguages.contains(language) ? UITableViewCellAccessoryType.checkmark : UITableViewCellAccessoryType.none
		return cell
	}

//# MARK: - Notifications

	func avSessionFailed(_ notification: NSNotification) {
		let alertView = UIAlertView(title: "AVSession Failed!", message: nil, delegate: nil, cancelButtonTitle:"OK")
		alertView.show()
	}

	func applicationDidEnterBackground(_ notification: NSNotification) {
		self.session?.stopRunning()
		self.clearScreenFromRegions()
		self.whiteBackgroundView.isHidden = true
		self.textCaptureService?.stopTasks()
		self.captureButton.isSelected = true
		self.isRunning = false
	}

	func applicationWillEnterForeground(_ notification: NSNotification) {
		self.session?.startRunning()
		self.isRunning = true
	}


//# MARK: - Actions

	@IBAction func onReconitionLanguages(_ sender: AnyObject) {
		if self.languagesTableView.isHidden {
			self.isRunning = false
			self.captureButton.isSelected = false
			self.languagesTableView.reloadData()
			self.languagesTableView.isHidden = false
		} else {
			self.tryToCloseLanguagesTable()
		}
	}

	@IBAction func capturePressed(_ sender: AnyObject) {
		if !self.captureButton.isEnabled {
			return
		}

		self.captureButton.isSelected = !self.captureButton.isSelected
		self.isRunning = self.captureButton.isSelected

		if self.isRunning {
			self.clearScreenFromRegions()
			self.whiteBackgroundView.isHidden = true
			self.session?.startRunning()
		} else {
			self.textCaptureService?.stopTasks()
		}
	}
    
    func showListViewControllerWithData(_ data: [String: Any]) {
        DispatchQueue.main.async {
            if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ShowListViewController") as? ShowListViewController {
                let chemList = ChemList(data: data)
                controller.chemList = chemList
                let navController = UINavigationController(rootViewController: controller) // Creating a navigation controller with VC1 at the root of the navigation stack.
                self.present(navController, animated: true, completion: nil)
            }
        }
    }
}

typealias RequestCompletion = (() -> Void)
extension RTRViewController {
    
    //MARK: API Methods
    
    func fetchAPIWithText(_ text: String) {
        var searchKey = text
        let maxLength = 252
        if text.characters.count > maxLength {
            searchKey = String(text.characters.prefix(maxLength))
        }
        let query = "\"\(searchKey)\"".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let urlString: String = "https://vast-dusk-78988.herokuapp.com/process/?q=" + query!
        if let url = URL(string: urlString) {
            let request = NSMutableURLRequest(url: url,
                                              cachePolicy: .useProtocolCachePolicy,
                                              timeoutInterval: 10.0)
            request.httpMethod = "GET"
            print("url : \(url)")
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { [weak self] (data, response, error) -> Void in
                if (error != nil) {
                    print(error!.localizedDescription)
                } else {
                    let httpResponse = response as? HTTPURLResponse
//                    print(httpResponse)
                    if httpResponse?.statusCode == 200, data != nil {
                        let json = try? JSONSerialization.jsonObject(with: data!, options: [])
                        if let dictionary = json as? [String: Any] {
                            print(dictionary)
                            self?.showListViewControllerWithData(dictionary)
                        }
                    }
                }
            })
            dataTask.resume()
        }
    }
    
}
