//
//  ShowListViewController.swift
//  TextCapture
//
//  Created by Prajwal on 07/10/17.
//  Copyright © 2017 HackInOut Inc. All rights reserved.
//

import UIKit
import AVFoundation

class ShowListViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    private let SessionPreset = AVCaptureSessionPreset1280x720
    private var session: AVCaptureSession?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    /// View with video preview layer
    @IBOutlet weak var previewView: UIView!
    @IBOutlet weak var tableView: UITableView!
    var chemList: ChemList?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.reloadData()
        configureAVCaptureSession()
        configurePreviewLayer()
        self.session?.startRunning()
        
        //blur bg behind table:
        let blurEffect = UIBlurEffect(style: .light)
        let blurView = UIVisualEffectView(effect: blurEffect)
        blurView.frame = previewView.bounds
        previewView.insertSubview(blurView, belowSubview: tableView)
        
        NotificationCenter.default.addObserver(self, selector:#selector(ShowListViewController.avSessionFailed(_:)), name: NSNotification.Name.AVCaptureSessionRuntimeError, object: nil)
        NotificationCenter.default.addObserver(self, selector:#selector(ShowListViewController.applicationDidEnterBackground(_:)), name: NSNotification.Name.UIApplicationDidEnterBackground, object: nil)
        NotificationCenter.default.addObserver(self, selector:#selector(ShowListViewController.applicationWillEnterForeground(_:)), name: NSNotification.Name.UIApplicationWillEnterForeground, object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        self.updatePreviewLayerFrame()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    private func configurePreviewLayer() {
        self.previewLayer = AVCaptureVideoPreviewLayer(session: self.session)
        self.previewLayer?.backgroundColor = UIColor.black.cgColor
        self.previewLayer?.videoGravity = AVLayerVideoGravityResize
        let rootLayer = self.previewView.layer
        rootLayer.insertSublayer(self.previewLayer!, at: 0)
        self.updatePreviewLayerFrame()
    }
    
    private func updatePreviewLayerFrame() {
//        DispatchQueue.main.async {
            let orientation = UIApplication.shared.statusBarOrientation
            self.previewLayer?.connection.videoOrientation = self.videoOrientation(orientation)
            let viewBounds = self.view.bounds
            self.previewLayer?.frame = viewBounds
//        }
    }
    
    private func configureAVCaptureSession() {
        self.session = AVCaptureSession()
        self.session?.sessionPreset = SessionPreset
        
        let device = AVCaptureDevice.defaultDevice(withMediaType: AVMediaTypeVideo)
        
        do {
            let input = try AVCaptureDeviceInput(device: device)
            assert((self.session?.canAddInput(input))!, "impossible to add AVCaptureDeviceInput")
            self.session?.addInput(input)
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        
        let videoDataOutput = AVCaptureVideoDataOutput()
        let videoDataOutputQueue = DispatchQueue(label: "videodataqueue", attributes: .concurrent)
        videoDataOutput.setSampleBufferDelegate(self, queue: videoDataOutputQueue)
        
        videoDataOutput.videoSettings = NSDictionary(object: Int(kCVPixelFormatType_32BGRA),
                                                     forKey: kCVPixelBufferPixelFormatTypeKey as! NSCopying) as [NSObject : AnyObject]
        
        assert((self.session?.canAddOutput(videoDataOutput))!, "impossible to add AVCaptureVideoDataOutput")
        self.session?.addOutput(videoDataOutput)
        
        let connection = videoDataOutput.connection(withMediaType: AVMediaTypeVideo)
        connection?.isEnabled = true
    }
    
    private func videoOrientation(_ orientation: UIInterfaceOrientation) -> AVCaptureVideoOrientation {
        switch orientation {
        case UIInterfaceOrientation.portrait:
            return AVCaptureVideoOrientation.portrait
        case UIInterfaceOrientation.portraitUpsideDown:
            return AVCaptureVideoOrientation.portraitUpsideDown
        case UIInterfaceOrientation.landscapeLeft:
            return AVCaptureVideoOrientation.landscapeLeft
        case UIInterfaceOrientation.landscapeRight:
            return AVCaptureVideoOrientation.landscapeRight
        default:
            return AVCaptureVideoOrientation.portrait
        }
    }

    //MARK: - Notifications
    
    func avSessionFailed(_ notification: NSNotification) {
        print("avSessionFailed")
    }
    
    func applicationDidEnterBackground(_ notification: NSNotification) {
        self.session?.stopRunning()
    }
    
    func applicationWillEnterForeground(_ notification: NSNotification) {
        self.session?.startRunning()
    }
    
    @IBAction func didTapBack(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}

extension ShowListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 { return "Elements" }
        else if section == 1 { return "Molecules" }
        else { return "Compounds" }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let chemicals = chemList else {
            return 0
        }
        if section == 0 { return chemicals.elements.count }
        else if section == 1 { return chemicals.molecules.count }
        else { return chemicals.compounds.count }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListCell", for: indexPath) as! ListTableViewCell
        if let chemicals = chemList {
            var text = ""
            let section = indexPath.section
            if section == 0 { text = chemicals.elements[indexPath.row].value }
            else if section == 1 { text =  chemicals.molecules[indexPath.row].value }
            else if section == 2 { text = chemicals.compounds[indexPath.row].value }
            cell.label.text = text
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let chemicals = chemList {
            var selectedChem: ChemData? = nil
            let section = indexPath.section
            if section == 0 { selectedChem = chemicals.elements[indexPath.row] }
            else if section == 1 { selectedChem =  chemicals.molecules[indexPath.row] }
            else if section == 2 { selectedChem = chemicals.compounds[indexPath.row] }
            if selectedChem != nil {
                print("Selected: \(selectedChem!.type) - \(selectedChem!.value)")
                if let controller = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ARViewController") as? ARViewController {
                    controller.searchName = selectedChem!.value
                    self.navigationController?.pushViewController(controller, animated: false)
                }
            }
        }
    }
    
}
