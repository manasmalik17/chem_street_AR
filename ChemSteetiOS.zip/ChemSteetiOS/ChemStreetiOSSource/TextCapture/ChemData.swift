//
//  ChemData.swift
//  TextCapture
//
//  Created by Prajwal on 08/10/17.
//  Copyright © 2017 HackInOut Inc. All rights reserved.
//

import Foundation

struct ChemList {
    var text: String = ""
    var elements = [ChemData]()
    var molecules = [ChemData]()
    var compounds = [ChemData]()
    init(data: [String : Any]) {
        if let entries = data["entities"] as? [String: Any] {
            if let elems = entries["element_name"] as? [[String:Any]] {
                for ele in elems {
                    elements.append(ChemData(data: ele))
                }
            }
            if let elems = entries["molecule_name"] as? [[String:Any]] {
                for ele in elems {
                    molecules.append(ChemData(data: ele))
                }
            }
            if let elems = entries["compound_name"] as? [[String:Any]] {
                for ele in elems {
                    molecules.append(ChemData(data: ele))
                }
            }
        }
        if let detectedText = data["_text"] as? String {
            text = detectedText
        }
    }
}

struct ChemData {
    var confidence: Int = 0
    var type: String = ""
    var value: String = ""
    init(data: [String : Any]) {
        confidence = (data["confidence"] as? Int) ?? 0
        type = (data["type"] as? String) ?? ""
        if type != "" {
            value = (data[type] as? String) ?? ""
        }
    }
}
