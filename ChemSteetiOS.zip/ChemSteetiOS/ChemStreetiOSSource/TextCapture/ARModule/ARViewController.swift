//
//  ARViewController.swift
//  TextCapture
//
//  Created by Prajwal on 08/10/17.
//  Copyright © 2017 HackInOut Inc. All rights reserved.
//

import UIKit
import SceneKit
import ARKit

struct ARDataModel {
    var csid: Int64 = 2322113
    var avgMass: Float = 0.0
    var molWeight: Float = 0.0
    var molFormula: String = ""
    var commanName: String = ""
    
    init(data: [String: Any]) {
        csid = data["csid"] as? Int64 ?? 2322113
        avgMass = data["average_mass"] as? Float ?? 0.0
        molWeight = data["molecular_weight"] as? Float ?? 0.0
        molFormula = data["molecular_formula"] as? String ?? ""
        commanName = data["common_name"] as? String ?? ""
    }
}

@available(iOS 11.0, *)
class ARViewController: UIViewController , ARSCNViewDelegate {

    var arModelData: ARDataModel?
    var searchName: String = "monohydrochloride"
    
    @IBOutlet var sceneView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "AR View"
        // Set the view's delegate
        sceneView.delegate = self
        // Show statistics such as fps and timing information
        sceneView.showsStatistics = true
        fetchAPIWithName(searchName)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        
        // Create a session configuration
        let configuration = ARWorldTrackingConfiguration()
        
        // Run the view's session
        sceneView.session.run(configuration)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Release any cached data, images, etc that aren't in use.
    }
    
    // MARK: - ARSCNViewDelegate
    
    /*
     // Override to create and configure nodes for anchors added to the view's session.
     func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
     let node = SCNNode()
     
     return node
     }
     */
    
    func session(_ session: ARSession, didFailWithError error: Error) {
        // Present an error message to the user
        
    }
    
    func sessionWasInterrupted(_ session: ARSession) {
        // Inform the user that the session has been interrupted, for example, by presenting an overlay
        
    }
    
    func sessionInterruptionEnded(_ session: ARSession) {
        // Reset tracking and/or remove existing anchors if consistent tracking is required
        
    }
}

extension ARViewController {
    //MARK: Render
    
    func renderScene() {
        
        if let arData = arModelData {
            
            // Create a new scene
            let scene = SCNScene(named: "art.scnassets/\(arData.csid).dae") ?? SCNScene(named: "art.scnassets/2322113.dae")!
            
            let childNodes = scene.rootNode.childNodes
            let chemScene = SCNScene()
            
            let modelNode = SCNNode()
            for child in childNodes {
                modelNode.addChildNode(child)
            }
            modelNode.scale = SCNVector3(x: 0.1, y: 0.1, z: 0.1)
            modelNode.position = SCNVector3(x: 0, y: -0.25, z: -2.0)
            
            //animation:
            let angle = Double.pi/2
            modelNode.pivot = SCNMatrix4MakeRotation(Float(angle), 1, 0, 0)
            chemScene.rootNode.addChildNode(modelNode)
            
            let spin = CABasicAnimation(keyPath: "rotation")
            spin.fromValue = NSValue(scnVector4: SCNVector4(x: 0, y: 0, z: -0.8, w: 0))
            spin.toValue = NSValue(scnVector4: SCNVector4(x: 0, y: 0, z: -0.8, w: Float(2 * Double.pi)))
            spin.duration = 3
            spin.repeatCount = .infinity
            modelNode.addAnimation(spin, forKey: "spin around")
            let rotate = SCNAction.repeatForever(SCNAction.rotateBy(x: 0.0, y: 0, z: CGFloat(angle), duration: 1.0))
            modelNode.runAction(rotate)
            
            let molFormula = "Mol Formula: " + arData.molFormula
            //adding molFormula:
            chemScene.rootNode.addTextNodeWithString(molFormula, position: SCNVector3(x: -0.3, y: 0.3, z: -2.5))
            
            let mass = "Avg. Mass: \(arData.avgMass)"
            //adding molFormula:
            chemScene.rootNode.addTextNodeWithString(mass, position: SCNVector3(x: -0.3, y: 0.45, z: -2.5))
            
            let weight = "Mol Weight: \(arData.molWeight) Mols"
            //adding molFormula:
            chemScene.rootNode.addTextNodeWithString(weight, position: SCNVector3(x: -0.3, y: 0.6, z: -2.5))
            
            let name = arData.commanName
            //adding molFormula:
            chemScene.rootNode.addTextNodeWithString(name, position: SCNVector3(x: -0.3, y: 0.75, z: -2.5))
            // Set the scene to the view
            sceneView.scene = chemScene
        }
    }
    
}

extension SCNNode {
    func addTextNodeWithString(_ text: String,
                             position: SCNVector3,
                                scale: SCNVector3 = SCNVector3(x: 0.008, y: 0.008, z: 0.008)) {
        let text = SCNText(string: text, extrusionDepth: 1)
        text.firstMaterial?.diffuse.contents = UIColor.blue
        let textNode = SCNNode(geometry: text)
        textNode.geometry = text
        textNode.position = position
        textNode.scale = scale
        self.addChildNode(textNode)
    }
}

extension ARViewController {
    
    //MARK: API Methods
    
    func fetchAPIWithName(_ name: String) {
        
        let query = "\"\(name)\"".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let urlString: String = "https://vast-dusk-78988.herokuapp.com/search/?q=" + query!
        if let url = URL(string: urlString) {
            let request = NSMutableURLRequest(url: url,
                                              cachePolicy: .useProtocolCachePolicy,
                                              timeoutInterval: 10.0)
            request.httpMethod = "GET"
            print("url : \(url)")
            let session = URLSession.shared
            let dataTask = session.dataTask(with: request as URLRequest, completionHandler: { [weak self] (data, response, error) -> Void in
                if (error != nil) {
                    print(error!.localizedDescription)
                } else {
                    let httpResponse = response as? HTTPURLResponse
                    //                    print(httpResponse)
                    if httpResponse?.statusCode == 200, data != nil {
                        let json = try? JSONSerialization.jsonObject(with: data!, options: [])
                        if let dictionary = json as? [String: Any] {
                            print(dictionary)
                            DispatchQueue.main.async {
                                self?.arModelData = ARDataModel(data: dictionary)
                                self?.renderScene()
                            }
                        }
                    }
                }
            })
            dataTask.resume()
        }
    }
    
}
